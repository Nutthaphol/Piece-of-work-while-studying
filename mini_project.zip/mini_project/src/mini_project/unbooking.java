package mini_project;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import java.time.LocalDate;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.sql.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class unbooking extends Application{
    private Connection con;
    private Statement stmt;
    private PreparedStatement pstmt;
    
    TextField name = new TextField();
    TextField rmID = new TextField();
    TextField phone = new TextField();
    
    DatePicker checkIn = new DatePicker();
    DatePicker checkOut = new DatePicker();
    
    //for calling from other page
    public unbooking(Connection con) throws SQLException {
        this.con = con;
        stmt =  con.createStatement();
    }
    
    @Override
    public void start(Stage primaryStage){           
        
        Text txtname = new Text("Name");
        txtname.setFont(Font.font("Times New Roman",FontWeight.BOLD,14));
        Text code = new Text("Room ID");
        code.setFont(Font.font("Times New Roman",FontWeight.BOLD,14));
        Text txtphone = new Text("Phone number");
        txtphone.setFont(Font.font("Times New Roman",FontWeight.BOLD,14));
        Text dateIn = new Text("Date check in");
        dateIn.setFont(Font.font("Times New Roman",FontWeight.BOLD,14));
        Text dateOut = new Text("Date check out");
        dateOut.setFont(Font.font("Times New Roman",FontWeight.BOLD,14));
       
        checkIn.setEditable(false);
        checkOut.setEditable(false);
        
        GridPane gpane = new GridPane();
        gpane.setAlignment(Pos.CENTER);
        gpane.setPadding(new Insets(10,10,10,10));
        gpane.setHgap(10);
        gpane.setVgap(10);
        
        gpane.add(txtname, 0, 0);
        gpane.add(code, 0, 1);
        gpane.add(txtphone, 0, 2);
        gpane.add(dateIn, 0, 3);
        gpane.add(dateOut, 0, 4);
        
        gpane.add(name, 1, 0);
        gpane.add(rmID, 1, 1);
        gpane.add(phone, 1, 2);
        gpane.add(checkIn, 1, 3);
        gpane.add(checkOut, 1, 4);
        
        Button btUnbook = new Button("Unbook");
        Button btBack = new Button("Back");
        
        HBox hb = new HBox(10);
        hb.setAlignment(Pos.CENTER);
        hb.setPadding(new Insets(10,10,10,10));
        hb.getChildren().addAll(btUnbook,btBack);
        
        VBox pane = new VBox();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(10,10,10,10));
        pane.getChildren().addAll(gpane,hb);
        
        Scene scene = new Scene(pane,600 ,450);
        primaryStage.setTitle("Unbooking Room");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        //send to UnbookingRoom function
        btUnbook.setOnAction(e->unbookingRoom());
        //back main
        btBack.setOnAction(e->{
            try {
                Main ex = new Main(true);
                ex.start(primaryStage);
            } 
            catch (Exception ex1) {
            }
        });
    }
    
     private void unbookingRoom(){
        String ID = rmID.getText();
        String n = name.getText();
        String ph = phone.getText();
        LocalDate daten = checkIn.getValue();
        LocalDate dateo = checkOut.getValue();
        
        try{
               //get data from booking table
               String queryString = "select * from booking";
               ResultSet rset = stmt.executeQuery(queryString);
               
               boolean have = true;
               
               while(rset.next())
               { 
                   String DateIn = String.valueOf(rset.getObject(4));
                   String DateOut = String.valueOf(rset.getObject(5));
                   LocalDate dateIn = LocalDate.parse(DateIn);
                   LocalDate dateOut = LocalDate.parse(DateOut);
                   
                   //check data, Is it same in database or not?
                   if(ID.equals(rset.getString(6))&&n.equals(rset.getString(2))&&ph.equals(rset.getString(3))&&daten.equals(dateIn)&&dateo.equals(dateOut))
                   {
                        //delete data in database
                        pstmt = con.prepareStatement("delete from booking where roomid=? and checkin=?;");
                        pstmt.setString(1, ID);
                        pstmt.setString(2, DateIn);
                        pstmt.executeUpdate();
                        
                        //notification for delete data
                        Alert a = new Alert(AlertType.INFORMATION);
                        a.setTitle("Unbooking");
                        a.setContentText("The room was unbooked");
                        a.showAndWait();
                        have = false;
                        break;
                   }
               }
               if(have)
               {
                    Alert a = new Alert(AlertType.WARNING);
                    a.setTitle("Haven't data");
                    a.setContentText("Haven't the data you send");
                    a.showAndWait();
               }
        }
        catch(SQLException ex){
           System.out.println("Error");
        }
     }

}
