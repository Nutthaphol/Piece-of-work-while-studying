package mini_project;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import java.time.LocalDate;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.sql.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class booking extends Application {
    private Statement stmt;
    private Connection con;
    private PreparedStatement ppstmt;

    private TextField name = new TextField();
    private TextField rmID = new TextField();
    private TextField phone = new TextField();
    
    private DatePicker checkIn = new DatePicker();
    private DatePicker checkOut = new DatePicker();
    
    private int back_before;
    
    //for calling from other page
    public booking(LocalDate In,LocalDate Out, Connection con, int before) throws SQLException {
        this.con = con;
        stmt = con.createStatement();
        checkIn.setValue(In);
        checkOut.setValue(Out);
        this.back_before = before;
    }
    public booking(Connection con, int before) throws SQLException {
        this.con = con;
        stmt = con.createStatement();
        checkIn.setValue(LocalDate.now());
        checkOut.setValue(LocalDate.now());
        this.back_before = before;
    }
    
    @Override
    public void start(Stage primaryStage){           
        ImageView staff = new ImageView(new Image("/Image/staff.png"));
        staff.setFitHeight(120);
        staff.setFitWidth(120);
        Text txtname = new Text("Name");
        Text code = new Text("Room ID");
        Text txtphone = new Text("Phone number");
        Text dateIn = new Text("Date check in");
        Text dateOut = new Text("Date check out");
       
        checkIn.setEditable(false);
        checkOut.setEditable(false);
        
        GridPane gpane = new GridPane();
        gpane.setAlignment(Pos.CENTER);
        gpane.setPadding(new Insets(10,10,10,10));
        gpane.setHgap(10);
        gpane.setVgap(10);
        
        gpane.add(txtname, 0, 0);
        gpane.add(code, 0, 1);
        gpane.add(txtphone, 0, 2);
        gpane.add(dateIn, 0, 3);
        gpane.add(dateOut, 0, 4);
        
        gpane.add(name, 1, 0);
        gpane.add(rmID, 1, 1);
        gpane.add(phone, 1, 2);
        gpane.add(checkIn, 1, 3);
        gpane.add(checkOut, 1, 4);
        
        Button btBook = new Button("Book");
        Button btBack = new Button("Back");
        
        HBox hb = new HBox(10);
        hb.setAlignment(Pos.CENTER);
        hb.setPadding(new Insets(10,10,10,10));
        hb.getChildren().addAll(btBook,btBack);
        
        VBox pane = new VBox();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(10,10,10,10));
        pane.getChildren().addAll(gpane,hb,staff);
        
        Scene scene = new Scene(pane,600,450);
        primaryStage.setTitle("Booking Room");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        //send to bookingRoom function
        btBook.setOnAction(e-> bookingRoom());
        
        //back to before;
        if(back_before == 1){
            btBack.setOnAction(e->{
                try {
                    check_room ex = new check_room(con);
                    ex.start(primaryStage);
                } 
                catch (Exception ex1) {
                }
            });
        }
        else if (back_before == 0){
            btBack.setOnAction(e->{
                try {
                    Main ex = new Main(true);
                    ex.start(primaryStage);
                } 
                catch (Exception ex1) {
                }
            });
        }
        else if (back_before == 2){
            btBack.setOnAction(e->{
                try {
                    room_status ex = new room_status(con);
                    ex.start(primaryStage);
                } 
                catch (Exception ex1) {
                    ex1.printStackTrace();
            }
            });
        }
        
    }
    
    private void bookingRoom(){
        String ID = rmID.getText();
        LocalDate dateCheckIn = checkIn.getValue();
        LocalDate datecheckOut = checkOut.getValue();
        String inPutCheckIn = String.valueOf(checkIn.getValue());
        String inPutCheckOut = String.valueOf(checkOut.getValue());
        
        try{
               boolean have = true;
               
                int dif = datecheckOut.compareTo(dateCheckIn);
                int difn = dateCheckIn.compareTo(LocalDate.now());
                if(dif>= 0 && difn>=0)
                {
                    //get bookcode from booking table
                    ResultSet rset2 = stmt.executeQuery("select bookcode from booking group by bookcode;");
                    int num = 1;
                    String temp;
                    //start line and go next line
                    while(rset2.next())
                    {
                        temp = String.valueOf(rset2.getObject(1));
                        int temp2 = Integer.parseInt(temp);
                        System.out.println(temp2);
                        if(num != temp2){
                            break;
                        }
                        num += 1;
                    }
                    System.out.print(num);
                    
                    ppstmt = con.prepareStatement("insert into booking value (?,?,?,?,?,?)");
                    String inputName = name.getText();
                    String inputPhone = phone.getText();
                    
                    ppstmt.setInt(1, num);
                    ppstmt.setString(2, inputName);
                    ppstmt.setString(3, inputPhone);
                    ppstmt.setString(4, inPutCheckIn);
                    ppstmt.setString(5, inPutCheckOut);
                    ppstmt.setString(6, ID);
                    ppstmt.executeUpdate();
                    
                    Alert a = new Alert(AlertType.INFORMATION);
                    a.setTitle("Book complete");
                    a.setContentText("การจองเสร็จสิ้น");
                    a.showAndWait();
                    have = false;
                }
                else
                {
                    Alert a = new Alert(AlertType.WARNING);
                            a.setTitle("Error date");
                            a.setContentText("ใส่ค่าวันที่ผิดพลาด กรุณาลองใหม่อีกครั้ง");
                            a.showAndWait();
               }
               if(have)
               {
                    Alert a = new Alert(AlertType.WARNING);
                    a.setTitle("Don't have that room");
                    a.setContentText("ไม่มีห้องดังกล่าวในฐานข้อมูล");
                    a.showAndWait();
               }
               rmID.setText("");
               name.setText("");
               phone.setText("");
        }
        catch(SQLException ex){
            ex.printStackTrace();
        }
    }

}
