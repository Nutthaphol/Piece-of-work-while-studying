package mini_project;

import java.sql.Connection;
import java.sql.Statement;
import javafx.application.Application;
import javafx.stage.Stage;
import java.sql.*;
import java.time.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import java.util.ArrayList;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import static javafx.scene.text.Font.font;
import javafx.scene.text.FontWeight;

public class check_room extends Application {

    private Statement stmt;
    private TextArea show_room;
    private Connection con;

    private LocalDate run;
    private LocalDate end;
    private Text ans;
    private DatePicker date_start;
    private DatePicker date_end;

    public check_room(Connection con) throws SQLException {
        this.con = con;
        stmt = con.createStatement();
    }

    @Override
    public void start(Stage checkroom) {
        Text ms_start = new Text("Start:\t");
        ms_start.setFont(Font.font("Verdana", FontWeight.BOLD, 16));
        ms_start.setFill(Color.GREEN);
        Text ms_end = new Text("End:\t\t");
        ms_end.setFont(Font.font("Verdana", FontWeight.BOLD, 16));
        ms_end.setFill(Color.RED);
        date_start = new DatePicker(LocalDate.now());
        date_end = new DatePicker(LocalDate.now());
        date_start.setEditable(false);
        date_end.setEditable(false);
        
        show_room = new TextArea();
        
        GridPane block_1 = new GridPane();
        block_1.add(ms_start, 0, 0);
        block_1.add(ms_end, 0, 1);
        block_1.add(date_start, 1, 0);
        block_1.add(date_end, 1, 1);
        block_1.setAlignment(Pos.CENTER);
        block_1.setPrefWidth(10);

        Button search = new Button("Search");
        
        show_room.setPadding(new Insets(10,10,10,10));
        show_room.setEditable(false);
        
        Button book = new Button("Book room");

        Button back = new Button("Back");
        VBox root = new VBox(10);
        root.getChildren().addAll(block_1, search, book,back, show_room);
        root.setAlignment(Pos.CENTER);

        Scene scene = new Scene(root, 600, 450);
        checkroom.setTitle("Check room");
        checkroom.setScene(scene);
        checkroom.show();
        column();
        search.setOnAction(e -> checkroom());
        
        //go to booking 
        book.setOnAction(e->{
           try{
               booking ex = new booking(date_start.getValue(),date_end.getValue(),con,1);
               ex.start(checkroom);
           }
           catch(Exception ex){}
        });
        
        //back to main
        back.setOnAction(e -> {
            try {
                Main ex = new Main(true);
                ex.start(checkroom);
            } catch (Exception ex1) {
            }
        });
    }
    
    private void column (){
        try{
            ResultSet rest = stmt.executeQuery("select * from room;");
            ResultSetMetaData reMeta = rest.getMetaData();
            show_room.appendText("\t\t\t\t\t\t\t");
            for (int i = 1; i<= reMeta.getColumnCount(); i++){
                show_room.appendText(reMeta.getColumnName(i));
                show_room.appendText("\t\t\t\t");
            }
            show_room.appendText("\n");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    private void checkroom (){
        System.out.println(date_start.getValue());
            System.out.println(date_end.getValue());
            show_room.clear();
            try {
                
                ResultSet rest = stmt.executeQuery("select * from room;");
                ResultSetMetaData reMeta = rest.getMetaData();
                show_room.appendText("\t\t\t\t\t\t\t");
                for (int i = 1; i<= reMeta.getColumnCount(); i++){
                    
                    show_room.appendText(reMeta.getColumnName(i));
                    show_room.appendText("\t\t\t\t");
                }
                show_room.appendText("\n");
                    
                LocalDate tempCheckIn = date_start.getValue();
                LocalDate tempCheckOut = date_end.getValue();
                    
                // select roomid that not free on the selected time 
                String command_sql = "select * from room,booking where (('"+tempCheckIn.toString()+"' between checkin and checkout) or ('"+tempCheckOut.toString()+"' between checkin and checkout )) and room.roomid = booking.roomid group by room.roomid;";
                ResultSet open = stmt.executeQuery(command_sql);
                ArrayList tempNotRoom = new ArrayList();
                while (open.next()) {
                    String tempS = String.valueOf(open.getObject(1));
                    int temp = Integer.parseInt(tempS);
                    tempNotRoom.add(temp);
                }
                System.out.println("\n");
                open.close(); 
                
                for (int i = 0; i < tempNotRoom.size();i++)
                {
                    System.out.println(tempNotRoom.get(i));
                }

                    
                // select all roomid
                String command_sql2 = "select roomid from room;";
                ResultSet open2 = stmt.executeQuery(command_sql2);
                
                ArrayList tempNotRoom2 = new ArrayList();
                while (open2.next()) {
                    String tempS = String.valueOf(open2.getObject(1));
                    int temp = Integer.parseInt(tempS);
                    tempNotRoom2.add(temp);
                }
                
                for (int i = 0; i < tempNotRoom2.size();i++)
                {
                    System.out.println(tempNotRoom2.get(i));
                }
                      
                // Cut roomid
                for (int i = 0; i < tempNotRoom2.size(); i++){
                    String tempFree2 = String.valueOf(tempNotRoom2.get(i));
                    boolean check = true;
                     for (int j = 0; j < tempNotRoom.size(); j++){
                        String tempFree = String.valueOf(tempNotRoom.get(j));
                        if (tempFree.equals(tempFree2)){
                            check = false;
                            System.out.println("ANS"+tempFree);
                        }
                    }
                    if (check){
                        String temp = String.valueOf(tempNotRoom2.get(i));

                        ResultSet print = stmt.executeQuery("select * from room where roomid = "+temp+";");
                        print.next();
                        show_room.appendText("\n");
                        show_room.appendText("\t\t\t\t\t\t\t");
                        for (int j = 1; j<= reMeta.getColumnCount(); j++){
                            String temp2 = String.valueOf(print.getObject(j));
                            if(temp2.equals("true")){
                                show_room.appendText("Ready");
                            }
                            else if(temp2.equals("false")){
                                show_room.appendText("Not ready");
                            }
                            else{
                                show_room.appendText(temp2);
                            }
                            show_room.appendText("\t\t\t\t\t");
                        }
                        
                    }
                    check = true;
                }
                  
            } catch (Exception ex) {
                ex.printStackTrace();
            }
    }
}
