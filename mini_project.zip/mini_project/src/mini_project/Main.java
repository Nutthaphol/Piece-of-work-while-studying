
package mini_project;

import java.sql.*;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class Main extends Application {

    private Statement stmt;
    private Connection con;
    private boolean login = false;

    public Main() {

    }
    public Main(boolean login) {
        this.login = login;
    }
    
       @Override
    public void start(Stage primaryStage) {
        initizeDB();
        VBox root = new VBox(10);
        VBox mainRoot = new VBox(20);
        Text welcome = new Text("Welcome to OBJECT-ORIENTED HOTEL");
        welcome.setStrokeWidth(1.5);
        welcome.setFont(Font.font("Verdana", FontWeight.BOLD, 26));
        welcome.setFill(Color.rgb(253, 253, 152));
        welcome.setStroke(Color.rgb(119, 221, 119));
        
        Button login_button = new Button("Login");
        Button checkRoom = new Button("Check room");
        Button roomStatus = new Button("Room status");
        Button unbook = new Button("Unbooking");
        Button booking = new Button("Booking");
        Button manage_button = new Button("Manage");
        
        root.getChildren().addAll(login_button, checkRoom, roomStatus, booking, unbook, manage_button);
        root.setAlignment(Pos.CENTER);
        
        mainRoot.getChildren().addAll(welcome, root);
        mainRoot.setAlignment(Pos.CENTER);
        
        Scene scene = new Scene(mainRoot, 600, 450);
        scene.setFill(Color.rgb(248, 225, 231));
        primaryStage.setTitle("Main Program");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        if(login){
            checkRoom.setOnAction(e -> {
                try {
                    check_room ex = new check_room(con);
                    ex.start(primaryStage);
                } 
                catch (Exception ex1) {
                }
            });

            booking.setOnAction(e->{
               try{
                    booking ex = new booking(con,0);
                    ex.start(primaryStage);  
               }
               catch(Exception ex1){
                   ex1.printStackTrace();
               }
            });

            roomStatus.setOnAction(e -> {
                try {
                    room_status ex = new room_status(con);
                    ex.start(primaryStage);
                } catch (Exception ex1) {
                    ex1.printStackTrace();
                }
            });

            unbook.setOnAction(e->{
                try{
                    unbooking ex = new unbooking(con);
                    ex.start(primaryStage);
                }
                catch(Exception ex){}
            });
            
            manage_button.setOnAction(e->{
                try{
                    manage ex = new manage(con);
                    ex.start(primaryStage);
                }
                catch (Exception ex1) {
                    ex1.printStackTrace();
                }
            });
            
        }
        else{
            login_button.setOnAction(e -> {
            try {
                login ex = new login(con);
                ex.start(primaryStage);
            } 
            catch (Exception ex1) {
            }
        });
        }
    }
    
    public static void main(String[] args) {
        launch(args);
    }

    private void initizeDB() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/book_hotel", "root", "Quntanutthaphol1810");
            stmt = con.createStatement();
  
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
