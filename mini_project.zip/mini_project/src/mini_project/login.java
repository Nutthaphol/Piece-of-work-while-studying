package mini_project;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.*;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;

/**
 *
 * @author User
 */
public class login extends Application {

    private Statement stmt;
    private PreparedStatement pre ;
    Connection con;
    TextField tfUser;
    PasswordField tfPass;
    Button btLogin = new Button("Login");
    private ResultSet result;
    
    
    public login(Connection con) throws SQLException{
        this.con = con;
        stmt = con.createStatement();
    }
    
    
    public void start(Stage primaryStage) throws ClassNotFoundException {
        Label LabelUser = new Label("Username :");
        Label LabelPass = new Label("Password :");
        HBox hbLogin = new HBox(15);
        HBox hbPass = new HBox(15);
        
        Button btLogin = new Button("Login");
        Button btRegister = new Button("Register");
        
        tfUser = new TextField();
        tfPass = new PasswordField();
        
        
        hbLogin.getChildren().addAll(LabelUser,tfUser);
        hbPass.getChildren().addAll(LabelPass,tfPass);
        
        Button back = new Button("Back");
        hbLogin.setAlignment(Pos.CENTER);
        hbPass.setAlignment(Pos.CENTER);
        HBox hbBt = new HBox(15);
        hbBt.getChildren().addAll(btLogin);
        hbBt.setAlignment(Pos.CENTER);
        VBox vb1 = new VBox(15);
        vb1.getChildren().addAll(hbLogin,hbPass,hbBt,back);
        vb1.setAlignment(Pos.CENTER);
        


        Scene scene = new Scene(vb1, 600, 450);
        
        primaryStage.setTitle("Login.");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        btLogin.setOnAction(e -> Connect(primaryStage));
        
        back.setOnAction(e -> {
            try {
                Main ex = new Main(false);
                ex.start(primaryStage);
            } catch (Exception ex1) {
            }
        });
        
    }
    
    private void Connect(Stage primaryStage){
           System.out.println(tfUser.getText());
           System.out.println(tfPass.getText());
           try{  
                   
                   String sql = "SELECT * FROM  login " +
                                "WHERE username = ? and password = ?";
                   pre = con.prepareStatement(sql);
                   
                   pre.setString(1,tfUser.getText());
                   pre.setString(2,tfPass.getText());
                   result = pre.executeQuery();
                    
               if(result.next()){
                 
                   if(tfPass.getText().equals(result.getString(2))){
                        
                       Alert a = new Alert(Alert.AlertType.INFORMATION);
                       a.setTitle("Login");
                       a.setContentText("เข้าสู่ระบบเสร็จสิ้น");
                       a.showAndWait();
                       Main ex = new Main(true);
                       ex.start(primaryStage);
                   }
               
            }
               else {
                   Alert a = new Alert(Alert.AlertType.CONFIRMATION);
                   a.setTitle("Login");
                   a.setContentText("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง");
                   a.showAndWait();
            }          
           }
               
            catch(SQLException ex){
                ex.printStackTrace();
            }
   
           //finally{tfUser.setText("");tfPass.setText("");}       
    }

    
    
}
