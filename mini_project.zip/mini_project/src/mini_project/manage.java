package mini_project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class manage extends Application {
    private final Statement stmt;
    private PreparedStatement pre ;
    Connection con;
    private ResultSet result;
    
        Button btEnter = new Button("Enter");
        Label lbRm = new Label("Room           ");
        Label lbStatus = new Label("Room Status");
        ComboBox<String> cbRm = new ComboBox();
        ComboBox<String> cbStatus = new ComboBox();
        
      ObservableList<String> listRm;
        
      public manage (Connection con) throws SQLException{
          this.con = con;
          stmt = con.createStatement();
      }
      
    @Override
    public void start(Stage primaryStage) throws Exception{
        room();

        cbStatus.getItems().addAll("Ready", "Not Ready");
        Button back = new Button("Back");
        HBox hb1 = new HBox(15);
        hb1.getChildren().addAll(lbRm,cbRm);
        hb1.setAlignment(Pos.CENTER_LEFT);
        HBox hb2 = new HBox(15);
        hb2.getChildren().addAll(lbStatus,cbStatus);
        hb2.setAlignment(Pos.CENTER_LEFT);
        VBox vb1 = new VBox(15);
        vb1.getChildren().addAll(hb1,hb2,btEnter,back);
        vb1.setAlignment(Pos.CENTER);

        vb1.setPadding(new Insets(20, 20, 20, 20));
        Scene scene = new Scene(vb1,600,450);
        
        primaryStage.setTitle("Manage");
        primaryStage.setScene(scene);
        primaryStage.show();
       
        btEnter.setOnAction(e -> Enter());
        scene.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.ENTER) {
                Enter();
            }
        });
        
        back.setOnAction(e -> {
            try {
                Main ex = new Main(true);
                ex.start(primaryStage);
            } catch (Exception ex1) {
            }
        });
    }
    
    private void room (){
        try{ 
            listRm = FXCollections.observableArrayList();
            String sql = "SELECT roomid FROM room " ;
            pre = con.prepareStatement(sql);
            result= pre.executeQuery(); 
            while (result.next()) {
                listRm.add(result.getString("roomid"));
                cbRm.setItems(listRm);
            }
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
    }

    private void Enter()  {
        String roomid = cbRm.getValue();
        String status = cbStatus.getValue();
        String sql = "SELECT * FROM  room WHERE roomid = ?";
            try{ 
                pre = con.prepareStatement(sql);
                pre.setString(1,roomid);
                result = pre.executeQuery();
                    if(result.next()){
                        if(cbRm.getValue().equals(result.getString(1))){
                            if(cbStatus.getValue().equals("Ready")){
                                 
                                pre.executeLargeUpdate("UPDATE room SET status = 1 WHERE roomid = "+cbRm.getValue()+"");
                                
                            }else if(cbStatus.getValue().equals("Not Ready")){
                                pre.executeLargeUpdate("UPDATE room SET status = 0 WHERE roomid = "+cbRm.getValue()+"");
                            }
                            Alert a = new Alert(Alert.AlertType.INFORMATION);
                            a.setTitle("Status Updated");
                            a.setContentText("อัปเดตสถานะห้องเรียบร้อย ");
                            a.showAndWait();        
                        }
                    }        
                }
                catch(SQLException ex){
                    ex.printStackTrace();
                }
        }
    

    
}
