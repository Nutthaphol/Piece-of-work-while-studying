package mini_project;

import java.net.URL;
import java.sql.*;
import java.time.LocalDate;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class room_status extends Application {
    private Connection con;
    private Statement stmt;
    private PreparedStatement pstmt;
    private TextField room;
    private Text ans;
    private TextArea show;
    
    public room_status (Connection con) throws SQLException{
        this.con = con;
        stmt =  con.createStatement();
    }
    
    @Override
    @SuppressWarnings("empty-statement")
    public void start(Stage primaryStage) {
        
        ImageView rn = new ImageView(new Image("/image/number.png"));
        rn.setFitHeight(150);
        rn.setFitWidth(150);
        
        room = new TextField();
        Text roomNumber = new Text("Room number :");
        roomNumber.setFont(Font.font("Times New Roman",FontWeight.BOLD,14));
        roomNumber.setFill(Color.BLUE);
        ans = new Text("");
        show = new TextArea();
        show.setEditable(false);
        
        HBox hb = new HBox(10);
        hb.setPadding(new Insets(10,10,10,10));
        hb.getChildren().addAll(roomNumber, room, ans);        
        hb.setAlignment(Pos.CENTER);
        Button book = new Button("Book room");
        Button back = new Button("Back");
        Button select = new Button("Select");
        
        VBox plane = new VBox(10);
        plane.getChildren().addAll(rn,hb, select, book,back,show);
        plane.setAlignment(Pos.CENTER);
        
        Scene scene = new Scene(plane, 600, 450);
        
        primaryStage.setTitle("Room status");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        select.setOnAction(e -> {
            LocalDate date = LocalDate.now();
            try{
                int Number = Integer.parseInt(room.getText());
                
                //Check if this room exists or not
                String query = "select roomid from room;";   
                ResultSet rset = stmt.executeQuery(query);
                boolean checkRoom = false;
                
                while (rset.next()) {
                    String get = String.valueOf(rset.getObject(1));
                    int keep = Integer.parseInt(get);
                    if(Number == keep)
                    {
                        checkRoom = true;
                    }
                }
                if(checkRoom){
                    pstmt = con.prepareStatement("select roomid,checkin,checkout from booking where ? between checkin and checkout group by roomid;");
                    pstmt.setString(1,date.toString());
                    ResultSet rset2 = pstmt.executeQuery();
                    
                    boolean checkStatus = true;
                    
                    // Check status room
                    while (rset2.next()) {            
                        String get = String.valueOf(rset2.getObject(1));
                        int keep = Integer.parseInt(get);
                        if (Number == keep){
                            checkStatus = false;
                        }
                    }

                    if(checkStatus){
                        ans.setText("   This Room Free");
                        show.clear();
                    }
                    else{
                        show.clear();
                        ans.setText("   This Room Not free");
                        column();
                        
                        ResultSet rset3 = stmt.executeQuery("select * from booking where roomid= "+Number+";");
                        ResultSetMetaData reMeta = rset3.getMetaData();
                        rset3.next();
                        show.appendText("\t");
                        for(int i=1; i<=reMeta.getColumnCount(); i++)
                            show.appendText(rset3.getObject(i) + "   \t      \t  ");
                        show.appendText("\n");
                        rset3.close();
                    }
                    rset2.next();  
                }
                else {
                    ans.setText("There is no room for this number.");
                }
                rset.close();
                 
            }
            catch (Exception ex) {
                ex.printStackTrace();
            } 
        });
        
         book.setOnAction(e->{
           try{
               booking ex = new booking(con,2);
               ex.start(primaryStage);
           }
           catch(Exception ex){}
        });
        
        back.setOnAction(e -> {
            try {
                Main ex = new Main(true);
                ex.start(primaryStage);
            } catch (Exception ex1) {
            }
        });
    }
    
    private void column (){
        try{
            ResultSet rest = stmt.executeQuery("select * from booking;");
            ResultSetMetaData reMeta = rest.getMetaData();

            for (int i = 1; i<= reMeta.getColumnCount(); i++){
                show.appendText(reMeta.getColumnName(i));
                show.appendText("  \t\t");
            }
            show.appendText("\n");
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

}
